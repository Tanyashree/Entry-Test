
var db={
    mongoDB:process.env.MONGO_DB || process.env.MONGODB
}
module.exports=db